# <img src="icons/128.png" width="45" align="left"> Minimal GitHub

> GitHub dashboard just like you wanted it to be.

## Screenshot

![Minimal GitHub](https://i.imgur.com/qZMqNks.png)

## License

[MIT](LICENSE)
